#!/bin/bash

echo "Hello, World!"
# 
# 
# To create and execute the script, follow these steps:
# 
# 1. Open a text editor and paste the above code snippet into a new file.
# 2. Save the file with a ".sh" extension, for example, "hello_world.sh".
# 3. Open a terminal or command prompt and navigate to the directory where you saved the script.
# 4. Make the script executable by running the following command: chmod +x hello_world.sh.
# 5. Finally, execute the script by running: ./hello_world.sh.
# 
