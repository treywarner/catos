#!/bin/bash
. $CATOS_PATH/catos_gvars
echo "I've edited the code you provided. Here is my file: $(sed 's/`/\\\\`/g' $catos_file  | sed 's/"/\\"/g') \
\
Pay attention to the edited code and base your changes off of that rather than the original. However, I still need your help: $1. Give me the code snippet of the whole script"
