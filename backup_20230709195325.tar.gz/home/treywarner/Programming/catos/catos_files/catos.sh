#!/bin/bash

# Get the current directory
current_dir=$(pwd)

# Create a timestamp for the backup filename
timestamp=$(date +"%Y%m%d%H%M%S")

# Define the backup filename
backup_filename="backup_${timestamp}.tar.gz"

# Create the backup
tar -czf "${backup_filename}" "${current_dir}"

echo "Backup created: ${backup_filename}"
#  Explanation ----------------- 
# 
# To use this script, follow these steps:
# 
# 1. Open a text editor and paste the above code into a new file.
# 2. Save the file with a desired name, such as backup_script.sh.
# 3. Open a terminal and navigate to the directory where you saved the script.
# 4. Make the script executable by running the command: chmod +x backup_script.sh
# 5. Run the script using the command: ./backup_script.sh
# 
