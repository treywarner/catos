#!/bin/bash
echo "Write a bash shell script that: $1. Give me the code snippet "
